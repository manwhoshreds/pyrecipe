from distutils.core import setup

setup(
    name='pyrecipe',
    version='0.8.0',
    packages=['pyrecipe',],
    license='GNU General Public License',
    long_description=open('README.rst').read()
)
